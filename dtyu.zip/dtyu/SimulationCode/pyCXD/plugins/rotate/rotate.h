//rotation
#include <stdio.h>
#include <stdlib.h>
#include "math.h"

int rotate(double *img1, double *img2, double theta, double cenx, double ceny, int dimx, int dimy);
void zero_elems(double *arr, int nopixels);
