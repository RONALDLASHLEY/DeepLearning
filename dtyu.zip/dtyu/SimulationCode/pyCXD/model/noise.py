#different types of scattering noise

