#!/bin/bash

nohup python run_fbb_svm.py --action 1 --label 0 
nohup python run_fbb_svm.py --action 1 --label 1 
nohup python run_fbb_svm.py --action 1 --label 2 
nohup python run_fbb_svm.py --action 1 --label 3 
nohup python run_fbb_svm.py --action 1 --label 4 
nohup python run_fbb_svm.py --action 1 --label 5 
nohup python run_fbb_svm.py --action 1 --label 6 
nohup python run_fbb_svm.py --action 1 --label 7 
nohup python run_fbb_svm.py --action 1 --label 8 
nohup python run_fbb_svm.py --action 1 --label 9 

